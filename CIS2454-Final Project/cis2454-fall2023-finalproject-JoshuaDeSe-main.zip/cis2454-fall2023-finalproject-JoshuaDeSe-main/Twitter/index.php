<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Lister</title>
    </head>
    <body>
        <h3 style="text-align:center;">Lister</h3>
        <?php include 'Views/navigation.php';?>
    </body>
    <?php include 'Views/footer.php';?>
</html>
