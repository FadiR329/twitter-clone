<?php

//set up class and functions to calls for combined post table

