<!DOCTYPE html>

<html>
    <footer style="text-align: center">
        Lister App - Dela Corp - &copy; 2024
    </footer>
</html>
