<!DOCTYPE html>
<html>
    <header style="text-align: center">
        <a href="index.php">Home</a>
        &nbsp;
        <!-- add links to these -->
        <a>Login</a>
        &nbsp;
        <a>Post</a>
    </header>
</html>
